SLUS-00844-1.mcd - https://gamefaqs.gamespot.com/ps/196911-chocobo-racing/saves  
    1. Dated 02/04/2001 By ATadeo - `All secret characters unlocked as well as the Final Fantasy VIII hidden track.`
    2. Dated 06/28/2011 By \_RockyAlananta_ - `Good Save, 8x Finish the Story Mode, all characters include Airship unlocked with GS 5, this save no bug 100%, no crash if u playing the game`