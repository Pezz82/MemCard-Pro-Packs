SCUS-94421-1.mcd - https://gamefaqs.gamespot.com/ps/198763-star-ocean-the-second-story/saves  
    1. Dated 12/29/2001 By FFRules `Ready to fight the Iselia Queen, 8 characters (Claude, Rena, Celine, Ashton, Precis, Leon, Chisato and Noel) at level 255 with best choice of equipment, all skills mastered, lots of weapons, items, and fol.`
    2. *ignore linked slot*
    3. Dated 01/22/2006 By Nightshadex2000 `Save Game to view the "Super Secret Reunion Ending 86". Starts in the Debug Room. Press "X" twice to view the ending. Reunion occurs after credits.`