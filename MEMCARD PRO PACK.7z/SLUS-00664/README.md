SLUS-00664-1.mcd - https://gamefaqs.gamespot.com/ps/199365-xenogears/saves  
    1. Dated 06/09/2003 By carlos2003 `Start of game, level 2, all items and Rps badge won.`
    2. Dated 06/20/2002 By CocaColaCat `Last save point, best equips, all deathblows learned, high levels`