SCUS-94163-1.mcd - https://gamefaqs.gamespot.com/ps/197341-final-fantasy-vii/saves - Dated 05/16/2019 Made by JagDogger2525 `1/This Guy R Sick//2/Cross Dress//3/Motorcycle//4/2nd Trip GS//5|6/Aerith//7|10/Start Disc//8/2nd Trip Capital//9/Hojo//11/GSauce Done//12/OutsideCrater-Full//13/Weaps//14/InCrater-Full//15/Debug Room`

SCUS-94163-2.mcd - https://gamefaqs.gamespot.com/ps/197341-final-fantasy-vii/saves - Dated 04/04/2003 Made by Nicolae6 `A rare save before the "date" with Barret. Just try to enter the ropeway.`

SCUS-94163-3.mcd - https://gamefaqs.gamespot.com/ps/197341-final-fantasy-vii/saves - Dated 05/15/2003 Made by Aether Knight `Disc 3 Save near Chocobo Ranch ready for Crater. ALL characters at level 99 with max stats. ALL Master Materia equipped! ALL equipment in game set to 99 including 2 of EVERY materia mastered, max Gil, max Gold, 1 of each Chocobo at ranch & all "weapons"`

SCUS-94163-4.mcd - https://gamefaqs.gamespot.com/ps/197341-final-fantasy-vii/saves - Dated 03/04/2001 Made by RMayfire `The rare date with Cloud & Yuffie. Saved right before the scene at the Golden Saucer on disc 1.`
