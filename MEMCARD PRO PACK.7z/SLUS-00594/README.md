SLUS-00594-1.mcd - https://gamefaqs.gamespot.com/ps/197909-metal-gear-solid/saves  
    1. Dated 06/06/2000 By TerratoZero `At the end,at the doorstep of the final room, everything you need to defeat Metal Gear.`
    2. Dated 08/05/2002 By Metallideth18 `New Game with normal mode. Stealth suit, unlimited ammo bandana, and tuxedo are unlocked.`