everything won and unlocked, trucks are unlicenced but I think those cant even be licenced
Tomáš Bílek